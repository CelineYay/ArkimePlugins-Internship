import requests 
import json 

url = 'https://ja4db.com/api/download'
response =  requests.get(url)

data = response.json()

with open('ja4+db.json' , 'w') as json_file:
    json.dump(data, json_file, indent=4)

print(f"JSON file downloaded and saved successfully with {len(data)} entries.")
#print ("JSON file downloaded and saved successfully")



# Load the JSON data from the file
input_file = 'ja4+db.json'
ja4output_file = 'ja4db.json'
ja4houtput_file = 'ja4hdb.json'
ja4toutput_file = 'ja4tdb.json'
ja4xoutput_file = 'ja4xdb.json'
ja4tscanoutput_file = 'ja4tscandb.json'

# Load the JSON data from the file
with open(input_file, 'r') as file:
    data = json.load(file)

# Define the filtering condition
filtered_data = [
    entry for entry in data
    if entry.get("ja4_fingerprint") is not None
    and not (entry.get("ja4s_fingerprint") or 
             entry.get("ja4t_fingerprint") or 
             entry.get("ja4ts_fingerprint") or 
             entry.get("ja4tscan_fingerprint") or 
             entry.get("ja4x_fingerprint"))
]

# Write the filtered data to a new file
with open(ja4output_file, 'w') as file:
    json.dump(filtered_data, file, indent=4)
    
print(f"Filtered data has been saved to {ja4output_file} with {len(filtered_data)} entries.")


####################################################################################################
####################################################################################################
####################################################################################################


# Define the filtering condition
filtered_data = [
    entry for entry in data
    if entry.get("ja4h_fingerprint") is not None
    and not (entry.get("ja4s_fingerprint") or 
             entry.get("ja4t_fingerprint") or 
             entry.get("ja4ts_fingerprint") or 
             entry.get("ja4tscan_fingerprint") or 
             entry.get("ja4x_fingerprint"))
]

# Write the filtered data to a new file
with open(ja4houtput_file, 'w') as file:
    json.dump(filtered_data, file, indent=4)


print(f"Filtered data has been saved to {ja4houtput_file} with {len(filtered_data)} entries.")




####################################################################################################
####################################################################################################
####################################################################################################


# Define the filtering condition
filtered_data = [
    entry for entry in data
    if entry.get("ja4t_fingerprint") is not None
    and not (entry.get("ja4s_fingerprint") or 
             entry.get("ja4h_fingerprint") or 
             entry.get("ja4ts_fingerprint") or 
             entry.get("ja4_fingerprint") or 
             entry.get("ja4tscan_fingerprint") or 
             entry.get("ja4x_fingerprint"))
]

# Write the filtered data to a new file
with open(ja4toutput_file, 'w') as file:
    json.dump(filtered_data, file, indent=4)

print(f"Filtered data has been saved to {ja4toutput_file} with {len(filtered_data)} entries.")


####################################################################################################
####################################################################################################
####################################################################################################


# Define the filtering condition
filtered_data = [
    entry for entry in data
    if entry.get("ja4x_fingerprint") is not None
    and not (entry.get("ja4s_fingerprint") or 
             entry.get("ja4h_fingerprint") or 
             entry.get("ja4_fingerprint") or 
             entry.get("ja4ts_fingerprint") or 
             entry.get("ja4tscan_fingerprint") or 
             entry.get("ja4t_fingerprint"))
]

# Write the filtered data to a new file
with open(ja4xoutput_file, 'w') as file:
    json.dump(filtered_data, file, indent=4)

print(f"Filtered data has been saved to {ja4xoutput_file} with {len(filtered_data)} entries.")


####################################################################################################
####################################################################################################
####################################################################################################


# Define the filtering condition
filtered_data = [
    entry for entry in data
    if entry.get("ja4tscan_fingerprint") is not None
    and not (entry.get("ja4s_fingerprint") or 
             entry.get("ja4h_fingerprint") or 
             entry.get("ja4_fingerprint") or 
             entry.get("ja4ts_fingerprint") or 
             entry.get("ja4x_fingerprint") or 
             entry.get("ja4t_fingerprint"))
]

# Write the filtered data to a new file
with open(ja4tscanoutput_file, 'w') as file:
    json.dump(filtered_data, file, indent=4)

print(f"Filtered data has been saved to {ja4tscanoutput_file} with {len(filtered_data)} entries.")


